import flet as ft
import random
import math
import time

# ==========================================
# 1. LÓGICA DE NEGOCIO (Tus objetos)
# ==========================================
class Moneda:
    def __init__(self):
        self.cara = 0
        self.cruz = 0
        self.opciones = [True, False]
        
    def tirar_moneda(self):
        tirada = random.choice(self.opciones)
        if tirada:
            self.cara += 1
        else:
            self.cruz += 1
        return tirada

class Evento:
    def __init__(self, numero, carta):
        self.numero = numero
        self.carta = carta

class Gestor:
    def __init__(self):
        self.mazo = [
            Evento(2, "Un buen año"),
            Evento(3, "Conflicto"), Evento(3, "Un bonito dia"),
            Evento(4, "Un bonito dia"), Evento(4, "La expulsion del bandido"), Evento(4, "La expulsion del bandido"),
            Evento(5, "Un bonito dia"), Evento(5, "Un bonito dia"), Evento(5, "Torneo de caballeria"), Evento(5, "Beneficios comerciales"),
            Evento(6, "Un bonito dia"), Evento(6, "Un bonito dia"), Evento(6, "Buenos vecinos"), Evento(6, "Epidemia"), Evento(6, "Terremoto"),
            Evento(8, "Un bonito dia"), Evento(8, "Un bonito dia"), Evento(8, "Un bonito dia"), Evento(8, "Un bonito dia"), Evento(8, "Epidemia"),
            Evento(9, "Un bonito dia"), Evento(9, "Un bonito dia"), Evento(9, "Un bonito dia"), Evento(9, "Mar en calma"),
            Evento(10, "Un bonito dia"), Evento(10, "Un bonito dia"), Evento(10, "Solidaridad"),
            Evento(11, "Un bonito dia"), Evento(11, "Solidaridad"),
            Evento(12, "Mar en calma")
        ]

    def sortear(self, un_numero):
        cartas_filtradas = [m for m in self.mazo if m.numero == un_numero]
        carta_elegida = random.choice(cartas_filtradas)
        return carta_elegida.carta

moneda_app = Moneda()
gestor_app = Gestor()


# ==========================================
# 2. INTERFAZ GRÁFICA
# ==========================================
def main(page: ft.Page):
    page.bgcolor = "#8a66a1" 
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.SPACE_BETWEEN 
    page.padding = 40

    # --- ELEMENTOS FIJOS ---
    titulo = ft.Text("Eventos de Catan", color=ft.colors.YELLOW_400, size=36, weight=ft.FontWeight.BOLD)
    
    texto_cara = ft.Text("Cara: 0", size=24, color=ft.colors.WHITE, weight=ft.FontWeight.BOLD)
    texto_cruz = ft.Text("Cruz: 0", size=24, color=ft.colors.WHITE, weight=ft.FontWeight.BOLD)
    fila_contadores = ft.Row([texto_cara, texto_cruz], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)


    # --- ETAPA 3: LA CARTA ---
    # fit=ft.ImageFit.CONTAIN se asegura de que la carta no se deforme aunque varíe la resolución del escaneo
    imagen_carta = ft.Image(src="", width=250, height=350, fit=ft.ImageFit.CONTAIN)
    
    def al_pulsar_volver(e):
        # Quitamos la carta y volvemos a mostrar la moneda
        page.controls.remove(contenedor_etapa3)
        page.controls.insert(1, boton_moneda)
        page.update()

    boton_volver = ft.ElevatedButton("Volver", width=150, height=50, color=ft.colors.WHITE, bgcolor=ft.colors.RED_700, on_click=al_pulsar_volver)
    
    contenedor_etapa3 = ft.Column(
        [imagen_carta, boton_volver],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=30
    )


    # --- ETAPA 2: MENÚ DE NÚMEROS ---
    numeros = [2, 3, 4, 5, 6, 8, 9, 10, 11, 12]
    filas_botones = []
    
    def al_pulsar_numero(e):
        numero_elegido = int(e.control.text)
        
        # 1. Le pedimos a tu gestor que sortee
        carta_sorteada = gestor_app.sortear(numero_elegido)
        
        # 2. Le decimos a la interfaz qué imagen cargar (asumimos extensión .jpg por ahora)
        imagen_carta.src = f"cartas/{carta_sorteada}.jpg"
        
        # 3. Transición visual: quitamos los botones y ponemos la carta
        page.controls.remove(contenedor_botones)
        page.controls.insert(1, contenedor_etapa3)
        page.update()

    for i in range(0, len(numeros), 2):
        btn1 = ft.ElevatedButton(text=str(numeros[i]), width=120, height=60, color=ft.colors.BLACK, on_click=al_pulsar_numero)
        btn2 = ft.ElevatedButton(text=str(numeros[i+1]), width=120, height=60, color=ft.colors.BLACK, on_click=al_pulsar_numero)
        filas_botones.append(ft.Row([btn1, btn2], alignment=ft.MainAxisAlignment.CENTER, spacing=20))
        
    contenedor_botones = ft.Column(filas_botones, spacing=20, alignment=ft.MainAxisAlignment.CENTER)


    # --- ETAPA 1: LA MONEDA ---
    def al_pulsar_moneda(e):
        boton_moneda.rotate.angle += math.pi * 2 
        resultado = moneda_app.tirar_moneda()
        
        texto_cara.value = f"Cara: {moneda_app.cara}"
        texto_cruz.value = f"Cruz: {moneda_app.cruz}"
        page.update()
        
        if resultado: 
            time.sleep(0.5) 
            page.controls.remove(boton_moneda)
            page.controls.insert(1, contenedor_botones)
            page.update()

    boton_moneda = ft.Container(
        content=ft.Text("TIRAR", size=20, weight=ft.FontWeight.BOLD, color=ft.colors.BROWN_900),
        width=150, height=150, bgcolor=ft.colors.AMBER_400, shape=ft.BoxShape.CIRCLE,
        alignment=ft.alignment.center, shadow=ft.BoxShadow(spread_radius=2, blur_radius=10, color=ft.colors.BLACK38),
        rotate=ft.transform.Rotate(0, alignment=ft.alignment.center),
        animate_rotation=ft.animation.Animation(600, ft.AnimationCurve.EASE_OUT_BACK),
        on_click=al_pulsar_moneda
    )


    # --- CARGA INICIAL ---
    page.add(titulo, boton_moneda, fila_contadores)

# IMPORTANTE: assets_dir="." permite que la app lea la carpeta "cartas" localmente.
ft.run(main, assets_dir="assets")
