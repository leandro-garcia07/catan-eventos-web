import flet as ft
import random
import math
import time

# ==========================================
# 1. LÓGICA DE NEGOCIO (Tus objetos)
# ==========================================
class Moneda:
    def __init__(self):
        self.cara = 0
        self.cruz = 0
        self.opciones = [True, False]
        
    def tirar_moneda(self):
        tirada = random.choice(self.opciones)
        if tirada:
            self.cara += 1
        else:
            self.cruz += 1
        return tirada

class Evento:
    def __init__(self, numero, carta):
        self.numero = numero
        self.carta = carta

class Gestor:
    def __init__(self):
        self.mazo = [
            Evento(2, "Un buen año"),
            Evento(3, "Conflicto"), Evento(3, "Un bonito dia"),
            Evento(4, "Un bonito dia"), Evento(4, "La expulsion del bandido"), Evento(4, "La expulsion del bandido"),
            Evento(5, "Un bonito dia"), Evento(5, "Un bonito dia"), Evento(5, "Torneo de caballeria"), Evento(5, "Beneficios comerciales"),
            Evento(6, "Un bonito dia"), Evento(6, "Un bonito dia"), Evento(6, "Buenos vecinos"), Evento(6, "Epidemia"), Evento(6, "Terremoto"),
            Evento(8, "Un bonito dia"), Evento(8, "Un bonito dia"), Evento(8, "Un bonito dia"), Evento(8, "Un bonito dia"), Evento(8, "Epidemia"),
            Evento(9, "Un bonito dia"), Evento(9, "Un bonito dia"), Evento(9, "Un bonito dia"), Evento(9, "Mar en calma"),
            Evento(10, "Un bonito dia"), Evento(10, "Un bonito dia"), Evento(10, "Solidaridad"),
            Evento(11, "Un bonito dia"), Evento(11, "Solidaridad"),
            Evento(12, "Mar en calma")
        ]

    def sortear(self, un_numero):
        cartas_filtradas = [m for m in self.mazo if m.numero == un_numero]
        carta_elegida = random.choice(cartas_filtradas)
        return carta_elegida.carta

moneda_app = Moneda()
gestor_app = Gestor()


# ==========================================
# 2. INTERFAZ GRÁFICA
# ==========================================

explicaciones_cartas = {
    "Un buen año": ('Cada persona obtiene la materia prima que desee de la reserva.\n'
    'Si se combina con Ciudades y Caballeros, no se puede obtener una mercancia.'),
    "Conflicto": ('Quien tenga más caballeros delante suyo o posea la tarjeta "Mayor ejército" le roba a otra persona 1 carta de la mano sin mirarla antes.\n' 
    'Si se combina con Ciudades y Caballeros, robará la carta quien tenga más puntos de fuerza con sus caballeros activos.'),
    "Un bonito dia": 'Al mostrar esta carta no tiene lugar ningún evento. Solamente se aplica el resultado de la tirada de producción que aparezca.',
    "La expulsion del bandido": 'Devuelve el ladrón al desierto. No se le roba ninguna carta a alguien que tenga un poblado o ciudad junto al desierto.',
    "Torneo de caballeria": ('La persona o personas que tengan más caballeros delante suyo, obtienen la materia prima que deseen de la reserva.\n' 
    'Si se combina con Ciudades y Caballeros, recibira la recompensa aquella persona (o personas) que tenga más puntos de fuerza teniendo en cuenta sus caballeros activos.\n' 
    'No está permitido obtener 1 mercancia.'),
    "Beneficios comerciales": 'Quien tenga la tarjeta de "Mayor ruta comercial" podrá robarle a otra persona 1 carta de la mano sin mirarla antes.',
    "Buenos vecinos": ('Cada persona elige una carta de su mano y la entrega a la persona de su izquierda (siempre que tenga al menos 1 carta).\n' 
    'Si se combina con Ciudades y Caballeros, se puede entregar 1 mercancía si se prefiere.'),
    "Epidemia": ('Durante la fase de producción las ciudades solo generan 1 materia prima.\n' 
    'Si se combina con Ciudades y Caballeros, no se pueden recibir mercancías.'),
    "Terremoto": ('Todas las personas giran una de sus carreteras 90° dejándola atravesada.\n' 
    'Antes de poder construir cualquier carretera deberás reparar primero esta carretera.\n' 
    'Coste de reparación: 1 madera + 1 arcilla.\n' 
    'Una carretera pendiente de reparación sigue contando a efectos de la mayor ruta comercial.\n'
    'No esta permitido construir un poblado junto a una carretera sin reparar.'),
    "Mar en calma": ('La persona o personas que tengan más poblados o ciudades junto a un puerto toman la materia prima que deseen de la reserva.\n' 
    'Si se combina con Ciudades y Caballeros, no se puede tomar 1 mercancía.'),
    "Solidaridad": ('La persona o personas que tengan más PV eligen una carta de su mano y la entregan a alguien que tenga menos puntos.\n' 
    'Si se combina con Ciudades y Caballeros, tambien se puede regalar 1 mercancía.')
}

def main(page: ft.Page):
    page.title = "Eventos de Catan"
    page.bgcolor = "#8a66a1" 
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.SPACE_BETWEEN 
    page.padding = 40

    # --- ELEMENTOS FIJOS ---
    # Texto de reglas concatenado
    texto_reglamento = (
        "REGLAMENTO:\n"
        "Eventos de Catan sigue las mismas reglas que en el juego básico, "
        "teniendo en cuenta que primero se resuelve el evento y luego el resultado de la tirada.\n\n"
        "MODO DE JUEGO:\n"
        "El jugador lanza los dados físicos, luego sortea si se aplicará Eventos de Catan a la tirada. "
        "Si no se aplican, el turno continúa normalmente.\n"
        "Si se aplican, seleccionará del menú el número correspondiente a su tirada y le será sorteado "
        "un evento aleatorio que se resolverá antes de continuar con el resultado de la tirada.\n\n"
        "LADRÓN:\n"
        "Cuando la tirada de producción sea 7 no se sorteará evento ya que el ladrón es su propio evento.\n"
        "Si se combina con Navegantes o Ciudades y Caballeros, cuando la tirada de producción sea 7 se "
        "mantendrá la forma de juego correspondiente a cada expansión (mover el ladrón o pirata en Navegantes, "
        "avanzar bárbaros y desplazar al ladrón luego del primer desembarco en Ciudades y Caballeros)."
    )

    # Lógica del Pop-up de reglas
    dialogo_reglas = ft.AlertDialog(
        title=ft.Text("Reglamento y Modo de Uso", weight=ft.FontWeight.BOLD),
        # Envolvemos el texto en una columna con scroll="auto" y altura fija
        content=ft.Column([ft.Text(texto_reglamento, size=14)], scroll="auto", height=350),
        actions=[ft.TextButton("Entendido", on_click=lambda e: cerrar_reglas(e))]
    )

    def abrir_reglas(e):
        page.dialog = dialogo_reglas
        dialogo_reglas.open = True
        page.update()

    def cerrar_reglas(e):
        dialogo_reglas.open = False
        page.update()

    # --- ETAPA 1: LA MONEDA ---
    def al_pulsar_moneda(e):
        boton_moneda.rotate.angle += math.pi * 2 
        resultado = moneda_app.tirar_moneda()
        
        texto_con_evento.value = f"Jugadas con Eventos: {moneda_app.cara}"
        texto_sin_evento.value = f"Jugadas sin Eventos: {moneda_app.cruz}"
        page.update()
        
        if resultado: 
            time.sleep(0.5) 
            page.controls.remove(boton_moneda)
            page.controls.insert(1, contenedor_botones)
            page.update()

    boton_moneda = ft.Container(
        content=ft.Text("Sortear", size=20, weight=ft.FontWeight.BOLD, color=ft.colors.BROWN_900),
        width=150, height=150, bgcolor=ft.colors.AMBER_400, shape=ft.BoxShape.CIRCLE,
        alignment=ft.alignment.center, shadow=ft.BoxShadow(spread_radius=2, blur_radius=10, color=ft.colors.BLACK38),
        rotate=ft.transform.Rotate(0, alignment=ft.alignment.center),
        animate_rotation=ft.animation.Animation(600, ft.AnimationCurve.EASE_OUT_BACK),
        on_click=al_pulsar_moneda
    )


# --- ENCABEZADO (TÍTULO Y REGLAMENTO) ---
    texto_titulo = ft.Text("Eventos de Catan", color=ft.colors.YELLOW_400, size=32, weight=ft.FontWeight.BOLD)
    boton_reglamento = ft.TextButton("Reglamento", on_click=abrir_reglas, style=ft.ButtonStyle(color=ft.colors.WHITE70))
    
    contenedor_encabezado = ft.Column([texto_titulo, boton_reglamento], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0)

    # --- CONTADORES ---
    texto_con_evento = ft.Text("Jugadas con Eventos: 0", size=16, color=ft.colors.WHITE, weight=ft.FontWeight.BOLD)
    texto_sin_evento = ft.Text("Jugadas sin Evento: 0", size=16, color=ft.colors.WHITE, weight=ft.FontWeight.BOLD)
    
    fila_contadores = ft.Column([texto_con_evento, texto_sin_evento], horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    # --- HISTORIAL Y REINICIO ---
    lista_historial = ft.ListView(spacing=10, height=150)
    
    def reiniciar_partida(e):
        moneda_app.cara = 0
        moneda_app.cruz = 0
        texto_con_evento.value = "Jugadas con Eventos: 0"
        texto_sin_evento.value = "Jugadas sin Evento: 0"
        
        lista_historial.controls.clear()
        
        if page.controls and contenedor_etapa3 in page.controls:
            page.controls.remove(contenedor_etapa3)
            page.controls.insert(1, boton_moneda)
        elif page.controls and contenedor_botones in page.controls:
            page.controls.remove(contenedor_botones)
            page.controls.insert(1, boton_moneda)
            
        page.update()

    boton_reinicio = ft.IconButton(icon=ft.icons.REFRESH, icon_color=ft.colors.WHITE, icon_size=24, on_click=reiniciar_partida)
    
    cabecera_historial = ft.Row(
        [
            ft.Text("Historial de Eventos:", weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
            boton_reinicio
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
    )

    contenedor_historial = ft.Column(
        [
            cabecera_historial,
            ft.Container(content=lista_historial, padding=10, bgcolor=ft.colors.BLACK26, border_radius=10)
        ]
    )
    texto_con_evento = ft.Text("Jugadas con Eventos: 0", size=16, color=ft.colors.WHITE, weight=ft.FontWeight.BOLD)
    texto_sin_evento = ft.Text("Jugadas sin Evento: 0", size=16, color=ft.colors.WHITE, weight=ft.FontWeight.BOLD)
    
    # Usamos Column en lugar de Row para apilarlos
    fila_contadores = ft.Column([texto_con_evento, texto_sin_evento], horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    # --- VENTANA DE AYUDA (Pop-up) ---
    texto_explicacion = ft.Text("Explicación aquí...")
    
    def cerrar_dialogo(e):
        dialogo_info.open = False
        page.update()

    dialogo_info = ft.AlertDialog(
        title=ft.Text("Regla del Evento", weight=ft.FontWeight.BOLD),
        content=texto_explicacion,
        actions=[ft.TextButton("Entendido", on_click=cerrar_dialogo)]
    )
    page.dialog = dialogo_info # Vincula el pop-up a la página


    # --- ETAPA 3: LA CARTA ---
    # fit=ft.ImageFit.CONTAIN se asegura de que la carta no se deforme aunque varíe la resolución del escaneo
    imagen_carta = ft.Image(src="", width=250, height=350, fit=ft.ImageFit.CONTAIN)
    
    def al_pulsar_volver(e):
        # Quitamos la carta y volvemos a mostrar la moneda
        page.controls.remove(contenedor_etapa3)
        page.controls.insert(1, boton_moneda)
        page.update()

    boton_volver = ft.ElevatedButton("Volver", width=150, height=50, color=ft.colors.WHITE, bgcolor=ft.colors.RED_700, on_click=al_pulsar_volver)
    
    def abrir_dialogo(e):
        page.dialog = dialogo_info
        dialogo_info.open = True
        page.update()

    boton_volver = ft.ElevatedButton("Volver", width=150, height=50, color=ft.colors.WHITE, bgcolor=ft.colors.RED_700, on_click=al_pulsar_volver)
    boton_info = ft.ElevatedButton("¿Qué hace?", icon=ft.icons.INFO, width=150, height=50, color=ft.colors.WHITE, bgcolor=ft.colors.BLUE_700, on_click=abrir_dialogo)
    
    # Agrupamos los dos botones en una fila
    fila_botones_carta = ft.Row([boton_volver, boton_info], alignment=ft.MainAxisAlignment.CENTER, spacing=20)
    
    contenedor_etapa3 = ft.Column(
        [imagen_carta, fila_botones_carta],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=30
    )


    # --- ETAPA 2: MENÚ DE NÚMEROS ---
    numeros = [2, 3, 4, 5, 6, 8, 9, 10, 11, 12]
    filas_botones = []
    
    def al_pulsar_numero(e):
        numero_elegido = int(e.control.text)
        
        # 1. Sortear la carta
        carta_sorteada = gestor_app.sortear(numero_elegido)
        
        # 2. Buscar la explicación en el diccionario (si no existe, muestra un texto por defecto)
        texto_explicacion.value = explicaciones_cartas.get(carta_sorteada, "Explicación no cargada aún.")

        # Calcular qué número de tirada es
        numero_tirada = len(lista_historial.controls) + 1
        
        # Insertar en la posición 0 (arriba) e incluir el número elegido en el texto
        lista_historial.controls.insert(
            0,
            ft.Row(
                [
                    ft.Text(f"Tirada {numero_tirada}:", color=ft.colors.YELLOW_400, weight=ft.FontWeight.BOLD),
                    ft.Text(f"Dado: {numero_elegido} - {carta_sorteada}", color=ft.colors.WHITE)
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
            )
        )
        
        # 3. Cargar la imagen
        imagen_carta.src = f"cartas/{carta_sorteada}.jpg"
        
        # 4. Transición visual
        page.controls.remove(contenedor_botones)
        page.controls.insert(1, contenedor_etapa3)
        page.update()

    for i in range(0, len(numeros), 2):
        btn1 = ft.ElevatedButton(text=str(numeros[i]), width=120, height=60, color=ft.colors.BLACK, bgcolor=ft.colors.YELLOW_600, on_click=al_pulsar_numero)
        btn2 = ft.ElevatedButton(text=str(numeros[i+1]), width=120, height=60, color=ft.colors.BLACK, bgcolor=ft.colors.YELLOW_600, on_click=al_pulsar_numero)
        filas_botones.append(ft.Row([btn1, btn2], alignment=ft.MainAxisAlignment.CENTER, spacing=20))
        
    contenedor_botones = ft.Column(filas_botones, spacing=20, alignment=ft.MainAxisAlignment.CENTER)




# --- CARGA INICIAL ---
    page.add(contenedor_encabezado, boton_moneda, fila_contadores, contenedor_historial)

# IMPORTANTE: assets_dir="." permite que la app lea la carpeta "cartas" localmente.
ft.app(target=main, assets_dir="assets")
